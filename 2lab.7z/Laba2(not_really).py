import cv2
import os
from pyzbar import pyzbar
import requests
from bs4 import BeautifulSoup
import warnings
warnings.filterwarnings("ignore")

RTSP_URL = 'rtsp://admin:admin@192.168.0.166:1935'

os.environ['OPENCV_FFMPEG_CAPTURE_OPTIONS'] = 'rtsp_transport;udp'

cap = cv2.VideoCapture(RTSP_URL, cv2.CAP_FFMPEG)

if not cap.isOpened():
    print('Cannot open RTSP stream')
    exit(-1)

recognized_barcodes = set()

# Поиск по штрих-коду на сайте
def check_barcode_online(barcode_data):
    url = f'https://barcode-list.ru/barcode/RU/%D0%9F%D0%BE%D0%B8%D1%81%D0%BA.htm?barcode={barcode_data}'
    try:
        response = requests.get(url)
        if response.status_code == 200:
            soup = BeautifulSoup(response.text, 'html.parser')
            product_info = soup.find("h1", {"class": "pageTitle"})
            
            if product_info:
                first_text_node = product_info.find(text=True)
                if first_text_node:
                    if first_text_node != f'Поиск:{barcode_data}':
                        print(first_text_node.strip())
                    else:
                        print(f"На сайте barcode-list нет такого товара")
                else:
                    print(f"Не удалось извлечь информацию для штрих-кода {barcode_data}.")
            else:
                print(f"Информация о товаре для штрих-кода {barcode_data} не найдена.")
        else:
            print(f"Не удалось получить данные для штрих-кода {barcode_data}. Статус код: {response.status_code}")
    except Exception as e:
        print(f"Ошибка при запросе информации о штрих-коде {barcode_data}: {e}")

# Найти штрих-код на экране и выделить
def decode_barcode(frame):
    barcodes = pyzbar.decode(frame)
    for barcode in barcodes:
        barcode_data = barcode.data.decode("utf-8")
        barcode_type = barcode.type

        if barcode_data not in recognized_barcodes:
            recognized_barcodes.add(barcode_data)
            
            print(f"Найден новый штрих-код: {barcode_data} ({barcode_type})")
            
            check_barcode_online(barcode_data)

        (x, y, w, h) = barcode.rect
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

        text = f"{barcode_data} ({barcode_type})"
        cv2.putText(frame, text, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
    
    return frame

while True:
    ret, frame = cap.read()
    if not ret:
        print("Failed to grab frame")
        break

    frame = decode_barcode(frame)

    cv2.imshow('RTSP stream', frame)

    if cv2.waitKey(1) == 27:
        break

    if cv2.getWindowProperty('RTSP stream', cv2.WND_PROP_VISIBLE) < 1:
        break

cap.release()
cv2.destroyAllWindows()
